package brun.ivan.pkg322;

import java.util.ArrayList;
import java.util.List;

public class Box {

    private List<Pieza> piezas;

    public Box() {
        this.piezas = new ArrayList<>();
    }

    public void agregarPieza(Pieza pieza) throws PiezaExistenteExcepcion {
        for (Pieza p : this.piezas) {
            if (p.getNombre().equals(pieza.getNombre()) && p.getUbicacion().equals(pieza.getUbicacion())) {
                throw new PiezaExistenteExcepcion("La pieza que intenta agregar es duplicada");
            }
        }
        this.piezas.add(pieza);
    }

    public void ajustarPiezas() {

        for (Pieza p : this.piezas) {

            if (p instanceof Ajustable) {

                Ajustable piezaAjustable = (Ajustable) p;
                piezaAjustable.ajustar();

            } else if (p instanceof Neumatico) {

                System.out.println("neumático '" + p.getNombre() + "' no puede ser ajustado.");
            }
        }
    }

    public void mostrarPiezas() {
        for (Pieza p : this.piezas) {
            System.out.println(p);

        }
    }

    public void buscarPiezasPorCondicionClimatica(CondicionClimatica condicion) {
        boolean hayPiezas = false;

        for (Pieza p : this.piezas) {
            if (p.getCondicion().equals(condicion)) {
                System.out.println(p);
                hayPiezas = true;

            }

        }
        if (hayPiezas == false) {
            System.out.println("No hay piezas que encajen con la condicion climatica pedida");
        }
    }
}
