
package brun.ivan.pkg322;


public class Motor extends Pieza implements Ajustable{
    private int potenciaMaxima;
    public Motor(String nombre, String ubicacion, CondicionClimatica condicion, int potenciaMaxima) {
        super(nombre, ubicacion, condicion);
        this.potenciaMaxima = potenciaMaxima;
    }

    @Override
    public void ajustar() {
        System.out.println("Soy un motor ajustandose");
    }



@Override
public String toString() {
   
    String infoPadre = super.toString(); 
   
    return "Motor " + infoPadre + ", Potencia Máxima: " + this.potenciaMaxima + "CV";
}
}
