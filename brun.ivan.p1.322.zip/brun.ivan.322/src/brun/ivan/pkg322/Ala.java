package brun.ivan.pkg322;

public class Ala extends Pieza implements Ajustable {

    private static final int cargaAerodinamicaMin = 1;
    private static final int cargaAerodinamicaMAX = 10;
    private int cargaAerodinamica;

    public Ala(int cargaAerodinamica, String nombre, String ubicacion, CondicionClimatica condicion) {
        super(nombre, ubicacion, condicion);
        setCargaAerodinamica(cargaAerodinamica);
    }

    private void setCargaAerodinamica(int cargaAerodinamica) {
        if (cargaAerodinamica < cargaAerodinamicaMin || cargaAerodinamica > cargaAerodinamicaMAX) {
            throw new IllegalArgumentException("La carga debe ser entre 1 y 10");
        }
        this.cargaAerodinamica = cargaAerodinamica;
    }

    @Override
    public void ajustar() {
        System.out.println("Soy un ala ajustandose");
    }

    @Override
    public String toString() {

        String infoPadre = super.toString();

        return "Ala" + infoPadre+ ", Carga Aerodinámica: " + this.cargaAerodinamica;
    }
}
