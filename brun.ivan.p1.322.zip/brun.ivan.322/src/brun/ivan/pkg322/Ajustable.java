
package brun.ivan.pkg322;


public interface Ajustable {
    public abstract void ajustar();
}
