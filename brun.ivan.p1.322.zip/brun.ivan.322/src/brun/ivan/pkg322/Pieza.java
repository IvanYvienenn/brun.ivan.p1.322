
package brun.ivan.pkg322;


public abstract class Pieza {
    private String nombre;
    private String ubicacion;
    private CondicionClimatica condicion;

    public Pieza(String nombre, String ubicacion, CondicionClimatica condicion) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.condicion = condicion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public CondicionClimatica getCondicion() {
        return condicion;
    }

    @Override
    public String toString() {
        return "Pieza{" + "nombre=" + nombre + ", ubicacion=" + ubicacion + ", condicion=" + condicion + '}';
    }
    
    
}
