
package brun.ivan.pkg322;

public enum CondicionClimatica {
    SECO,
    LLUVIA,
    MIXTO;
}
