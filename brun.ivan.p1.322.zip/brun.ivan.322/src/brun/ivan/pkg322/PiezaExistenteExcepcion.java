
package brun.ivan.pkg322;

public class PiezaExistenteExcepcion extends Exception{

    public PiezaExistenteExcepcion(String message) {
        super(message);
    }
    
}
