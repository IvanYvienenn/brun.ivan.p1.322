
package brun.ivan.pkg322;


public enum TipoCompuesto {
    SOFT,
    MEDIUM,
    HARD,
    WET,
    INTERMEDIO;
}
