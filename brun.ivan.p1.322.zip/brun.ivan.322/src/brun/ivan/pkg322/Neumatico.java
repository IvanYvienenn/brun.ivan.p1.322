package brun.ivan.pkg322;

public class Neumatico extends Pieza {

    private TipoCompuesto compuesto;

    public Neumatico(TipoCompuesto compuesto, String nombre, String ubicacion, CondicionClimatica condicion) {
        super(nombre, ubicacion, condicion);
        this.compuesto = compuesto;
    }

    @Override
    public String toString() {

        String infoPadre = super.toString();

        return "Neumático" + infoPadre+ ", Compuesto: " + this.compuesto;
    }

}
